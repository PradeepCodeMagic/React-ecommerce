import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import { Link, useLocation } from 'react-router-dom'

export default function ProductDetails() {

  let currentLocatiom = useLocation() //location + object-return

  let pId = currentLocatiom.pathname.split("/")[2]


  let [singleData, setsingleData] = useState([])
  let [bidImg, setbidImg] = useState([])
  let [smallImg, setsmallImg] = useState([])
  // WORK
  let singleMyProduts = () => {
    let apiUrl = "https://dummyjson.com/products/" + pId



    axios.get(apiUrl)
      .then(function (response) {
        setsingleData(response.data);
        console.log(response.data)
        setbidImg(response.data.thumbnail)
        setsmallImg(response.data.images)
      })

  }
  useEffect(() => {
    singleMyProduts()
  }, [])

  return (
    <div>
      <div class="container my-5">
        <Button className='my-2'>
          <Link className='Button' to={"/"}> Go Home page </Link>
        </Button>
        <div class="row">
          <div class="col-md-5">
            <div class="main-img">
              <img class="img-fluid" src={bidImg} />

              <div class="row my-3 previews">
                {smallImg.map((v) => {
                  return (
                    <div class="col">
                      <img class="w-100" onClick={() => setbidImg(v)} src={v} alt="Sale" />
                    </div>
                  )
                })}

              </div>
            </div>
          </div>
          <div class="col-md-7">
            <div class="main-description px-2">
              <div class="category text-bold">
                Category: {singleData.category}
              </div>
              <div class="product-title text-bold my-3">
                {singleData.title}
              </div>


              <div class="price-area my-4">
                <p class="old-price mb-1"><del>$100</del> <span class="old-price-discount text-danger">(20% off)</span></p>
                <p class="new-price text-bold mb-1">${singleData.price}</p>
                <p class="text-secondary mb-1">(Additional tax may apply on checkout)</p>

              </div>


              <div class="buttons d-flex my-5">
                <div class="block">
                  <a href="#" class="shadow btn custom-btn ">Wishlist</a>
                </div>
                <div class="block">
                  <button class="shadow btn custom-btn">Add to cart</button>
                </div>

                <div class="block quantity">
                  <input type="number" class="form-control" id="cart_quantity" value="1" min="0" max="5" placeholder="Enter email" name="cart_quantity" />
                </div>
              </div>




            </div>

            <div class="product-details my-4">
              <p class="details-title text-color mb-1">Product Details</p>
              <p class="description">{singleData.description} </p>
            </div>

            <h4> {singleData.brand} </h4>


          </div>
        </div>
      </div>


    </div>


  )
}
