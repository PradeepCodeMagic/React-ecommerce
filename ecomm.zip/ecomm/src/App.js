import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import { Link } from 'react-router-dom';


function App() {
  let [product, setproduct] = useState([])
  let [catt, setcatt] = useState([])
 


  let apiUrl



  let Allproducts = (myCatp="") => {
    console.log(myCatp)

    if(myCatp==""){
      apiUrl = "https://dummyjson.com/products"
    }
    else{
      apiUrl = "https://dummyjson.com/products" +"/category/" +myCatp
    }

    axios.get(apiUrl)
      .then(function (response) {
        setproduct(response.data.products);
      })

  }

  // catt-work
  let Allcat = () => {
    axios.get(apiUrl + "/categories")
      .then(function (response) {
        // setproduct(response.data.products);
        setcatt(response.data)
      })

  }

  useEffect(() => {
    Allproducts()
    Allcat()
  }, [])
  return (
    <div className="App mt-3">
      <div className='container'>
        <div className='row'>
          <div className='col-lg-4'>
            <h2> All categories </h2>

            <div className='my-2'>
              <ListGroup>
                {catt.map((p,k)=>{
                  return(
                    <ListGroup.Item className='catOne' key={k} onClick={()=>Allproducts(p)}>{p} </ListGroup.Item>
                  )
                })}
              </ListGroup>
            </div>
          </div>

          <div className='col-lg-8  p-0 m-0' >
            <h2>All Produts </h2>
            <div className='row row-cols-3'>
              {product.map((v, i) => {
                return (
                  <div className='my-1'>
                    <Card style={{ width: '16rem' }}>
                      <Card.Img variant="top" src={v.thumbnail} height={200} />
                      <Card.Body>
                        <Card.Title> {v.title} </Card.Title>
                        <h5> category:-{v.category} </h5>
                        <h3>price:- {v.price} </h3>
                        <Card.Text>
                          {v.brand}
                        </Card.Text>
                        <Button >
                          <Link className='Button' to={`/products/${v.id}`}> Go somewhere </Link>
                        </Button>
                      </Card.Body>
                    </Card>
                  </div>
                )
              })}


            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
